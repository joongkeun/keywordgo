﻿namespace keywordGOGO
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.keywordTbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.saveBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.label66 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.label37 = new System.Windows.Forms.Label();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.label36 = new System.Windows.Forms.Label();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.label35 = new System.Windows.Forms.Label();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.label34 = new System.Windows.Forms.Label();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label33 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label32 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.g5_btn = new System.Windows.Forms.Button();
            this.g4_btn = new System.Windows.Forms.Button();
            this.g3_btn = new System.Windows.Forms.Button();
            this.g2_btn = new System.Windows.Forms.Button();
            this.g1_btn = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.g7_btn = new System.Windows.Forms.Button();
            this.g6_btn = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.webBrowser2 = new System.Windows.Forms.WebBrowser();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.webBrowser4 = new System.Windows.Forms.WebBrowser();
            this.webBrowser3 = new System.Windows.Forms.WebBrowser();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.instaDataGridView = new System.Windows.Forms.DataGridView();
            this.webBrowser6 = new System.Windows.Forms.WebBrowser();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.instatagBox = new System.Windows.Forms.TextBox();
            this.instarTagBtn = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.webBrowser5 = new System.Windows.Forms.WebBrowser();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.webBrowser7 = new System.Windows.Forms.WebBrowser();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.label82 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instaDataGridView)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.keywordTbox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(368, 74);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "키워드 검색";
            // 
            // keywordTbox
            // 
            this.keywordTbox.Location = new System.Drawing.Point(61, 20);
            this.keywordTbox.Name = "keywordTbox";
            this.keywordTbox.Size = new System.Drawing.Size(297, 21);
            this.keywordTbox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "* 검색할 키워드를 넣어주세요";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "검색어 : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(807, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 12);
            this.label12.TabIndex = 14;
            this.label12.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(732, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "진행사항 :";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(734, 32);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(721, 136);
            this.listBox1.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(64, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(125, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "/ 25000건(일)";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(380, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(335, 48);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "네이버 Open API 일일 사용량";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(144, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "건";
            // 
            // saveBtn
            // 
            this.saveBtn.Location = new System.Drawing.Point(380, 57);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(335, 111);
            this.saveBtn.TabIndex = 16;
            this.saveBtn.Text = "키워드 분석";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(6, 82);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(368, 86);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "검색조건";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Location = new System.Drawing.Point(6, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(354, 55);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "광고센터 연관 검색량 선택";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(10, 25);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(75, 16);
            this.radioButton1.TabIndex = 13;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "상위 50건";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(265, 25);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(83, 16);
            this.radioButton4.TabIndex = 26;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "조회전체건";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(91, 25);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(81, 16);
            this.radioButton2.TabIndex = 24;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "상위 100건";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(178, 25);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(81, 16);
            this.radioButton3.TabIndex = 25;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "상위 300건";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(435, 515);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(101, 16);
            this.checkBox2.TabIndex = 28;
            this.checkBox2.Text = "SEO 태그검색";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(10, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1469, 923);
            this.tabControl1.TabIndex = 18;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox12);
            this.tabPage7.Controls.Add(this.groupBox11);
            this.tabPage7.Controls.Add(this.groupBox10);
            this.tabPage7.Controls.Add(this.groupBox9);
            this.tabPage7.Controls.Add(this.groupBox8);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1461, 897);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "프로그램 안내";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.linkLabel11);
            this.groupBox12.Controls.Add(this.label70);
            this.groupBox12.Controls.Add(this.label69);
            this.groupBox12.Controls.Add(this.label67);
            this.groupBox12.Controls.Add(this.linkLabel10);
            this.groupBox12.Controls.Add(this.label66);
            this.groupBox12.Controls.Add(this.pictureBox2);
            this.groupBox12.Location = new System.Drawing.Point(20, 541);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(998, 342);
            this.groupBox12.TabIndex = 13;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "유용한 정보";
            // 
            // linkLabel11
            // 
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.Location = new System.Drawing.Point(14, 244);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Size = new System.Drawing.Size(244, 12);
            this.linkLabel11.TabIndex = 20;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "https://smartstore.naver.com/appleprinter";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(50, 188);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(173, 12);
            this.label70.TabIndex = 19;
            this.label70.Text = "커스텀 휴대폰 케이스 전문제작";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label69.Location = new System.Drawing.Point(69, 210);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(135, 24);
            this.label69.TabIndex = 18;
            this.label69.Text = "애플트리몰";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(6, 26);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(265, 12);
            this.label67.TabIndex = 17;
            this.label67.Text = "메뉴가 직관적이고 가격이 저렴한 방문택배 어플";
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.Location = new System.Drawing.Point(61, 139);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Size = new System.Drawing.Size(155, 12);
            this.linkLabel10.TabIndex = 16;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Text = "http://www.parcelman.kr/";
            this.linkLabel10.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel10_LinkClicked_1);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(112, 140);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(53, 12);
            this.label66.TabIndex = 15;
            this.label66.Text = "파슬맨 : ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(33, 45);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(210, 83);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label68);
            this.groupBox11.Controls.Add(this.label65);
            this.groupBox11.Controls.Add(this.linkLabel9);
            this.groupBox11.Controls.Add(this.label64);
            this.groupBox11.Controls.Add(this.label63);
            this.groupBox11.Controls.Add(this.label62);
            this.groupBox11.Controls.Add(this.label61);
            this.groupBox11.Controls.Add(this.label60);
            this.groupBox11.Controls.Add(this.label59);
            this.groupBox11.Controls.Add(this.label58);
            this.groupBox11.Controls.Add(this.label56);
            this.groupBox11.Controls.Add(this.label57);
            this.groupBox11.Location = new System.Drawing.Point(1024, 540);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(417, 343);
            this.groupBox11.TabIndex = 12;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "프로그램 정보";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(79, 324);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(257, 12);
            this.label68.TabIndex = 41;
            this.label68.Text = "Copyrightⓒ2020 본아이티 All rights reserved.";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(19, 270);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(101, 12);
            this.label65.TabIndex = 40;
            this.label65.Text = "참여코드 : GOGO";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.Location = new System.Drawing.Point(19, 246);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(217, 12);
            this.linkLabel9.TabIndex = 15;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "https://open.kakao.com/o/g4wjxW1b";
            this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("굴림", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label64.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label64.Location = new System.Drawing.Point(19, 223);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(326, 12);
            this.label64.TabIndex = 39;
            this.label64.Text = "+ 오픈채팅 커뮤니티 (사용방법, 정보공유) 참여하기 +";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(19, 147);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(176, 12);
            this.label63.TabIndex = 38;
            this.label63.Text = "- 여유 저장공간 100Mbyte 이상";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(19, 189);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(317, 12);
            this.label62.TabIndex = 37;
            this.label62.Text = ":: 이하 사양에서는 정상 동작을 하지 않을 수도 있습니다. ";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(19, 125);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(113, 12);
            this.label61.TabIndex = 36;
            this.label61.Text = "- 메모리 4기가 이상";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(19, 103);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(110, 12);
            this.label60.TabIndex = 35;
            this.label60.Text = "- intel Core i3 이상";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(19, 167);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(192, 12);
            this.label59.TabIndex = 34;
            this.label59.Text = "- .NET  프레임워크 4.6 이상 설치 ";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label58.Location = new System.Drawing.Point(19, 39);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(57, 12);
            this.label58.TabIndex = 33;
            this.label58.Text = "권장사양";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(19, 81);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(163, 12);
            this.label56.TabIndex = 32;
            this.label56.Text = "- 운영체제 : 윈도우10 64비트";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label57.Location = new System.Drawing.Point(19, 59);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(157, 12);
            this.label57.TabIndex = 31;
            this.label57.Text = "- 화면크기 : 1920*1080 이상";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label81);
            this.groupBox10.Controls.Add(this.label73);
            this.groupBox10.Controls.Add(this.label74);
            this.groupBox10.Controls.Add(this.label54);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Controls.Add(this.label52);
            this.groupBox10.Controls.Add(this.label53);
            this.groupBox10.Controls.Add(this.label50);
            this.groupBox10.Controls.Add(this.label51);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label49);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.label45);
            this.groupBox10.Controls.Add(this.label44);
            this.groupBox10.Controls.Add(this.label43);
            this.groupBox10.Controls.Add(this.label42);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Controls.Add(this.label41);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Controls.Add(this.label38);
            this.groupBox10.Location = new System.Drawing.Point(20, 14);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(602, 520);
            this.groupBox10.TabIndex = 11;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "메뉴설명";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(6, 79);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(127, 12);
            this.label81.TabIndex = 33;
            this.label81.Text = "- 결과내 조건검색기능";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(6, 367);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(335, 12);
            this.label73.TabIndex = 32;
            this.label73.Text = "- 같이사용한 해시태그를 검색하고 해당페이지로 이동합니다.";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label74.Location = new System.Drawing.Point(6, 345);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(57, 12);
            this.label74.TabIndex = 31;
            this.label74.Text = "인별고고";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 491);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(251, 12);
            this.label54.TabIndex = 30;
            this.label54.Text = "- 프로그램 업데이트 버전 정보를 확인하세요.";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label55.Location = new System.Drawing.Point(6, 469);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(88, 12);
            this.label55.TabIndex = 29;
            this.label55.Text = "업데이트 정보";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 425);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(327, 12);
            this.label52.TabIndex = 28;
            this.label52.Text = "- 빅데이터 기반 키워드 통계, 분석 서비스 웹페이지 입니다.";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label53.Location = new System.Drawing.Point(6, 403);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(57, 12);
            this.label53.TabIndex = 27;
            this.label53.Text = "블랙키위";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 316);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(159, 12);
            this.label50.TabIndex = 26;
            this.label50.Text = "- 모바일, 데스크탑 동시검색";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label51.Location = new System.Drawing.Point(6, 294);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(57, 12);
            this.label51.TabIndex = 25;
            this.label51.Text = "쇼핑검색";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 259);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(195, 12);
            this.label48.TabIndex = 24;
            this.label48.Text = "- 네이버 데이터랩 웹페이지입니다.";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label49.Location = new System.Drawing.Point(6, 237);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(83, 12);
            this.label49.TabIndex = 23;
            this.label49.Text = "쇼핑인사이트";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 202);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(159, 12);
            this.label47.TabIndex = 22;
            this.label47.Text = "- 조회 데이터 엑셀 출력기능";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 182);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(375, 12);
            this.label45.TabIndex = 21;
            this.label45.Text = "- 키워드 광고시 광고비를 입력하여 현재와 직전 검색 광고비를 비교 ";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 161);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(183, 12);
            this.label44.TabIndex = 20;
            this.label44.Text = "- 현재와 직전검색 과거순위 제공";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 161);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(0, 12);
            this.label43.TabIndex = 19;
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 97);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(159, 12);
            this.label42.TabIndex = 18;
            this.label42.Text = "- 조회 데이터 엑셀 출력기능";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 141);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(203, 12);
            this.label40.TabIndex = 17;
            this.label40.Text = "- 광고상품 순위, 일반상품 순위 검색";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label41.Location = new System.Drawing.Point(6, 119);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(57, 12);
            this.label41.TabIndex = 16;
            this.label41.Text = "순위검색";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 60);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(512, 12);
            this.label39.TabIndex = 15;
            this.label39.Text = "- 광고연관검색, 쇼핑연관검색어, 상품에 많이 쓰인단어, SEO 태그, 연관검색어 관련 상품조회";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label38.Location = new System.Drawing.Point(6, 42);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(75, 12);
            this.label38.TabIndex = 0;
            this.label38.Text = "키워드 검색";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.linkLabel8);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.linkLabel7);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.linkLabel6);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.linkLabel5);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.linkLabel4);
            this.groupBox9.Controls.Add(this.linkLabel3);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.linkLabel2);
            this.groupBox9.Controls.Add(this.label32);
            this.groupBox9.Controls.Add(this.linkLabel1);
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Location = new System.Drawing.Point(628, 14);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(390, 520);
            this.groupBox9.TabIndex = 10;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "유용한 사이트";
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.Location = new System.Drawing.Point(19, 405);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(278, 12);
            this.linkLabel8.TabIndex = 14;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "https://gongu.copyright.or.kr/freeFontEvent.html";
            this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(19, 389);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(81, 12);
            this.label37.TabIndex = 13;
            this.label37.Text = "안심 글꼴파일";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Location = new System.Drawing.Point(19, 361);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(183, 12);
            this.linkLabel7.TabIndex = 12;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "https://modu-print.tistory.com/";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 345);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(81, 12);
            this.label36.TabIndex = 11;
            this.label36.Text = "모두의 프린터";
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Location = new System.Drawing.Point(19, 314);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(204, 12);
            this.linkLabel6.TabIndex = 10;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "https://blog.naver.com/darkwalk77";
            this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel6_LinkClicked);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(19, 298);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(133, 12);
            this.label35.TabIndex = 9;
            this.label35.Text = "파일명 한번에 변경하기";
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Location = new System.Drawing.Point(19, 259);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(146, 12);
            this.linkLabel5.TabIndex = 8;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "http://x.photoscape.org/";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(19, 241);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(139, 12);
            this.label34.TabIndex = 7;
            this.label34.Text = "포토스케이프 (사진편집)";
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Location = new System.Drawing.Point(19, 204);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(184, 12);
            this.linkLabel4.TabIndex = 6;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "https://www.mangoboard.net/ ";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Location = new System.Drawing.Point(19, 182);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(151, 12);
            this.linkLabel3.TabIndex = 5;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "https://www.canva.com/";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(19, 161);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(133, 12);
            this.label33.TabIndex = 4;
            this.label33.Text = "배너 상세페이지 만들기";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(19, 122);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(161, 12);
            this.linkLabel2.TabIndex = 3;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "https://www.remove.bg/ko";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(19, 103);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(279, 12);
            this.label32.TabIndex = 2;
            this.label32.Text = "누끼만들어주는 사이트(무료 최대 사이즈 500X500)";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(19, 64);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(169, 12);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://www.photopea.com/";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(19, 46);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(53, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "웹포토샵";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.pictureBox1);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Location = new System.Drawing.Point(1024, 14);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(417, 520);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "후원안내";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.Location = new System.Drawing.Point(163, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 16);
            this.label24.TabIndex = 1;
            this.label24.Text = "후원안내";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(169, 306);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 8;
            this.label30.Text = "카카오페이";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(141, 215);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "개발자에게 커피 한잔";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(151, 329);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(94, 260);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(209, 12);
            this.label25.TabIndex = 2;
            this.label25.Text = "카카오뱅크 3333-09-9007217(이중근) ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(33, 117);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(337, 12);
            this.label29.TabIndex = 6;
            this.label29.Text = "개인시간을 투자하여 개발 및 업데이트를  진행하고 있습니다.";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(41, 90);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(321, 12);
            this.label26.TabIndex = 3;
            this.label26.Text = "본 프로그램은 개인이 제작하여 무료로 배포하고 있습니다.";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(62, 144);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(278, 12);
            this.label28.TabIndex = 5;
            this.label28.Text = "지속적인 업데이트와 개발을 위해 후원해주세요 : )";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(123, 192);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(157, 12);
            this.label27.TabIndex = 4;
            this.label27.Text = "본 프로그램이 유용하셨다면";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label80);
            this.tabPage1.Controls.Add(this.label79);
            this.tabPage1.Controls.Add(this.label75);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.label78);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.label77);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.label76);
            this.tabPage1.Controls.Add(this.checkBox2);
            this.tabPage1.Controls.Add(this.g5_btn);
            this.tabPage1.Controls.Add(this.g4_btn);
            this.tabPage1.Controls.Add(this.g3_btn);
            this.tabPage1.Controls.Add(this.g2_btn);
            this.tabPage1.Controls.Add(this.g1_btn);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.dataGridView7);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.dataGridView4);
            this.tabPage1.Controls.Add(this.dataGridView5);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.dataGridView6);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.saveBtn);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1461, 897);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "키워드검색";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(873, 180);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(29, 12);
            this.label80.TabIndex = 55;
            this.label80.Text = "이하";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(670, 180);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 12);
            this.label79.TabIndex = 54;
            this.label79.Text = "이상";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(400, 180);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(29, 12);
            this.label75.TabIndex = 53;
            this.label75.Text = "이상";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(914, 174);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(163, 23);
            this.button3.TabIndex = 52;
            this.button3.Text = "결과내 조건검색";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(767, 175);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 21);
            this.textBox7.TabIndex = 51;
            this.textBox7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox7_KeyPress);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(713, 180);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(49, 12);
            this.label78.TabIndex = 50;
            this.label78.Text = "상품수 :";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(563, 175);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 21);
            this.textBox6.TabIndex = 49;
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(444, 180);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(121, 12);
            this.label77.TabIndex = 48;
            this.label77.Text = "월간 모바일 검색수 : ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(292, 175);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 21);
            this.textBox5.TabIndex = 47;
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(194, 181);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(102, 12);
            this.label76.TabIndex = 46;
            this.label76.Text = "월간 PC 검색수 : ";
            // 
            // g5_btn
            // 
            this.g5_btn.Location = new System.Drawing.Point(1380, 508);
            this.g5_btn.Name = "g5_btn";
            this.g5_btn.Size = new System.Drawing.Size(75, 23);
            this.g5_btn.TabIndex = 45;
            this.g5_btn.Text = "엑셀출력";
            this.g5_btn.UseVisualStyleBackColor = true;
            this.g5_btn.Click += new System.EventHandler(this.g5_btn_Click);
            // 
            // g4_btn
            // 
            this.g4_btn.Location = new System.Drawing.Point(586, 512);
            this.g4_btn.Name = "g4_btn";
            this.g4_btn.Size = new System.Drawing.Size(49, 23);
            this.g4_btn.TabIndex = 44;
            this.g4_btn.Text = "엑셀";
            this.g4_btn.UseVisualStyleBackColor = true;
            this.g4_btn.Click += new System.EventHandler(this.g4_btn_Click);
            // 
            // g3_btn
            // 
            this.g3_btn.Location = new System.Drawing.Point(367, 512);
            this.g3_btn.Name = "g3_btn";
            this.g3_btn.Size = new System.Drawing.Size(49, 23);
            this.g3_btn.TabIndex = 43;
            this.g3_btn.Text = "엑셀";
            this.g3_btn.UseVisualStyleBackColor = true;
            this.g3_btn.Click += new System.EventHandler(this.g3_btn_Click);
            // 
            // g2_btn
            // 
            this.g2_btn.Location = new System.Drawing.Point(127, 512);
            this.g2_btn.Name = "g2_btn";
            this.g2_btn.Size = new System.Drawing.Size(49, 23);
            this.g2_btn.TabIndex = 42;
            this.g2_btn.Text = "엑셀";
            this.g2_btn.UseVisualStyleBackColor = true;
            this.g2_btn.Click += new System.EventHandler(this.g2_btn_Click);
            // 
            // g1_btn
            // 
            this.g1_btn.Location = new System.Drawing.Point(1380, 175);
            this.g1_btn.Name = "g1_btn";
            this.g1_btn.Size = new System.Drawing.Size(75, 23);
            this.g1_btn.TabIndex = 41;
            this.g1_btn.Text = "엑셀출력";
            this.g1_btn.UseVisualStyleBackColor = true;
            this.g1_btn.Click += new System.EventHandler(this.g1_btn_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(651, 521);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(101, 12);
            this.label23.TabIndex = 40;
            this.label23.Text = "상품 & 쇼핑몰 정보";
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(653, 536);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowTemplate.Height = 23;
            this.dataGridView7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView7.Size = new System.Drawing.Size(802, 352);
            this.dataGridView7.TabIndex = 39;
            this.dataGridView7.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellClick);
            this.dataGridView7.SortCompare += new System.Windows.Forms.DataGridViewSortCompareEventHandler(this.dataGridView7_SortCompare);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(431, 536);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(204, 352);
            this.dataGridView1.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 518);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(159, 12);
            this.label7.TabIndex = 36;
            this.label7.Text = "* 상품명에 많이 쓰이는 단어";
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(190, 536);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(226, 352);
            this.dataGridView4.TabIndex = 35;
            this.dataGridView4.SortCompare += new System.Windows.Forms.DataGridViewSortCompareEventHandler(this.dataGridView4_SortCompare);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(13, 536);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.Size = new System.Drawing.Size(163, 352);
            this.dataGridView5.TabIndex = 34;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 518);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 12);
            this.label8.TabIndex = 33;
            this.label8.Text = "* 쇼핑 연관 검색어 ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 181);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(179, 12);
            this.label22.TabIndex = 32;
            this.label22.Text = "* 연관 검색어 검색 결과 종합 ||";
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(12, 206);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowTemplate.Height = 23;
            this.dataGridView6.Size = new System.Drawing.Size(1443, 298);
            this.dataGridView6.TabIndex = 31;
            this.dataGridView6.SelectionChanged += new System.EventHandler(this.dataGridView6_SelectionChanged);
            this.dataGridView6.SortCompare += new System.Windows.Forms.DataGridViewSortCompareEventHandler(this.dataGridView6_SortCompare);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label82);
            this.tabPage5.Controls.Add(this.dataGridView8);
            this.tabPage5.Controls.Add(this.g7_btn);
            this.tabPage5.Controls.Add(this.g6_btn);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.dataGridView3);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.dataGridView2);
            this.tabPage5.Controls.Add(this.listBox2);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1461, 897);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "순위검색";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // g7_btn
            // 
            this.g7_btn.Location = new System.Drawing.Point(1383, 130);
            this.g7_btn.Name = "g7_btn";
            this.g7_btn.Size = new System.Drawing.Size(75, 23);
            this.g7_btn.TabIndex = 47;
            this.g7_btn.Text = "엑셀출력";
            this.g7_btn.UseVisualStyleBackColor = true;
            this.g7_btn.Click += new System.EventHandler(this.g7_btn_Click);
            // 
            // g6_btn
            // 
            this.g6_btn.Location = new System.Drawing.Point(635, 130);
            this.g6_btn.Name = "g6_btn";
            this.g6_btn.Size = new System.Drawing.Size(75, 23);
            this.g6_btn.TabIndex = 46;
            this.g6_btn.Text = "엑셀출력";
            this.g6_btn.UseVisualStyleBackColor = true;
            this.g6_btn.Click += new System.EventHandler(this.g6_btn_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(714, 141);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 12);
            this.label18.TabIndex = 13;
            this.label18.Text = "일반상품 순위";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 141);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 12);
            this.label17.TabIndex = 7;
            this.label17.Text = "광고상품 순위";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(716, 156);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(742, 317);
            this.dataGridView3.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(869, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(11, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(798, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 10;
            this.label14.Text = "진행사항 : ";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 156);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(698, 317);
            this.dataGridView2.TabIndex = 9;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(797, 26);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(661, 100);
            this.listBox2.TabIndex = 8;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label46);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.textBox4);
            this.groupBox6.Controls.Add(this.textBox2);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Location = new System.Drawing.Point(12, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(779, 123);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "순위조회";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(73, 102);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(185, 12);
            this.label46.TabIndex = 8;
            this.label46.Text = "* 광고를 안한 경우 0을 넣으세요.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(73, 84);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(199, 12);
            this.label19.TabIndex = 7;
            this.label19.Text = "* 키워드에 쓰인 광고비를 넣으세요.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 6;
            this.label16.Text = "광고비 : ";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(75, 57);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(245, 21);
            this.textBox4.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(75, 20);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(245, 21);
            this.textBox2.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "쇼핑몰명 : ";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(662, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "조회";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(341, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "키워드 : ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(397, 20);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(245, 21);
            this.textBox3.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.webBrowser2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1461, 897);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "쇼핑인사이트";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // webBrowser2
            // 
            this.webBrowser2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser2.Location = new System.Drawing.Point(0, 0);
            this.webBrowser2.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser2.Name = "webBrowser2";
            this.webBrowser2.Size = new System.Drawing.Size(1461, 897);
            this.webBrowser2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.webBrowser4);
            this.tabPage4.Controls.Add(this.webBrowser3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1461, 897);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "쇼핑검색";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(533, 55);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "검색어";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(347, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "검색";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(334, 21);
            this.textBox1.TabIndex = 4;
            this.textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(544, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "데스크탑";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(19, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "모바일";
            // 
            // webBrowser4
            // 
            this.webBrowser4.Location = new System.Drawing.Point(558, 92);
            this.webBrowser4.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser4.Name = "webBrowser4";
            this.webBrowser4.ScriptErrorsSuppressed = true;
            this.webBrowser4.Size = new System.Drawing.Size(900, 792);
            this.webBrowser4.TabIndex = 1;
            // 
            // webBrowser3
            // 
            this.webBrowser3.Location = new System.Drawing.Point(3, 92);
            this.webBrowser3.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser3.Name = "webBrowser3";
            this.webBrowser3.ScriptErrorsSuppressed = true;
            this.webBrowser3.Size = new System.Drawing.Size(533, 792);
            this.webBrowser3.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label72);
            this.tabPage8.Controls.Add(this.label71);
            this.tabPage8.Controls.Add(this.instaDataGridView);
            this.tabPage8.Controls.Add(this.webBrowser6);
            this.tabPage8.Controls.Add(this.groupBox13);
            this.tabPage8.ForeColor = System.Drawing.Color.Black;
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1461, 897);
            this.tabPage8.TabIndex = 8;
            this.tabPage8.Text = "인별고고";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(9, 80);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(263, 12);
            this.label72.TabIndex = 6;
            this.label72.Text = "더블클릭 - 관련 해시태그를 조회후 페이지 이동";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(9, 60);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(271, 12);
            this.label71.TabIndex = 5;
            this.label71.Text = "한번클릭 - 해당 해시태그로 인별그램 페이지이동";
            // 
            // instaDataGridView
            // 
            this.instaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.instaDataGridView.Location = new System.Drawing.Point(9, 99);
            this.instaDataGridView.Name = "instaDataGridView";
            this.instaDataGridView.RowTemplate.Height = 23;
            this.instaDataGridView.Size = new System.Drawing.Size(332, 794);
            this.instaDataGridView.TabIndex = 4;
            this.instaDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.instaDataGridView_CellClick);
            this.instaDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.instaDataGridView_CellDoubleClick);
            // 
            // webBrowser6
            // 
            this.webBrowser6.Location = new System.Drawing.Point(348, 13);
            this.webBrowser6.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser6.Name = "webBrowser6";
            this.webBrowser6.Size = new System.Drawing.Size(1110, 881);
            this.webBrowser6.TabIndex = 3;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.instatagBox);
            this.groupBox13.Controls.Add(this.instarTagBtn);
            this.groupBox13.Location = new System.Drawing.Point(3, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(338, 49);
            this.groupBox13.TabIndex = 2;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "인별그램 해시태그";
            // 
            // instatagBox
            // 
            this.instatagBox.Location = new System.Drawing.Point(6, 17);
            this.instatagBox.Name = "instatagBox";
            this.instatagBox.Size = new System.Drawing.Size(245, 21);
            this.instatagBox.TabIndex = 1;
            // 
            // instarTagBtn
            // 
            this.instarTagBtn.Location = new System.Drawing.Point(257, 15);
            this.instarTagBtn.Name = "instarTagBtn";
            this.instarTagBtn.Size = new System.Drawing.Size(75, 23);
            this.instarTagBtn.TabIndex = 0;
            this.instarTagBtn.Text = "검색";
            this.instarTagBtn.UseVisualStyleBackColor = true;
            this.instarTagBtn.Click += new System.EventHandler(this.instarTagBtn_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.webBrowser5);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1461, 897);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "블랙키위";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // webBrowser5
            // 
            this.webBrowser5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser5.Location = new System.Drawing.Point(0, 0);
            this.webBrowser5.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser5.Name = "webBrowser5";
            this.webBrowser5.ScriptErrorsSuppressed = true;
            this.webBrowser5.Size = new System.Drawing.Size(1461, 897);
            this.webBrowser5.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.webBrowser7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1461, 897);
            this.tabPage2.TabIndex = 6;
            this.tabPage2.Text = "업데이트 정보";
            // 
            // webBrowser7
            // 
            this.webBrowser7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser7.Location = new System.Drawing.Point(0, 0);
            this.webBrowser7.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser7.Name = "webBrowser7";
            this.webBrowser7.Size = new System.Drawing.Size(1461, 897);
            this.webBrowser7.TabIndex = 0;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(250, 250);
            this.webBrowser1.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.ForeColor = System.Drawing.Color.Crimson;
            this.label20.Location = new System.Drawing.Point(10, 17);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(11, 12);
            this.label20.TabIndex = 19;
            this.label20.Text = "-";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Location = new System.Drawing.Point(811, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(664, 36);
            this.groupBox7.TabIndex = 20;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Notice";
            // 
            // dataGridView8
            // 
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(12, 502);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.RowTemplate.Height = 23;
            this.dataGridView8.Size = new System.Drawing.Size(1446, 379);
            this.dataGridView8.TabIndex = 48;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(10, 487);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(173, 12);
            this.label82.TabIndex = 49;
            this.label82.Text = "전체 순위목록(최대 400위까지)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1491, 959);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "키워드고고(v1.1.0)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instaDataGridView)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox keywordTbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button g5_btn;
        private System.Windows.Forms.Button g4_btn;
        private System.Windows.Forms.Button g3_btn;
        private System.Windows.Forms.Button g2_btn;
        private System.Windows.Forms.Button g1_btn;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.WebBrowser webBrowser2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.WebBrowser webBrowser4;
        private System.Windows.Forms.WebBrowser webBrowser3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.WebBrowser webBrowser5;
        private System.Windows.Forms.WebBrowser webBrowser7;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button g7_btn;
        private System.Windows.Forms.Button g6_btn;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.LinkLabel linkLabel10;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox instatagBox;
        private System.Windows.Forms.Button instarTagBtn;
        private System.Windows.Forms.DataGridView instaDataGridView;
        private System.Windows.Forms.WebBrowser webBrowser6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.DataGridView dataGridView8;
    }
}

